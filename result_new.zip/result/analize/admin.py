import django
from django.contrib import admin
from .models import Mydata,Reference
admin.site.register(Mydata)
admin.site.register(Reference)

# Register your models here.
