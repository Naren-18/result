from audioop import reverse
from cgi import test
from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from matplotlib.style import context
# from pyparsing import col
# from sqlalchemy import column
import tabula
import pandas as pd
import numpy as np
import os
from .models import Mydata,Reference


# Create your views here.
sem=0
rows=0
pass_y=0
midroll=0
detain=[]
subjects=[]
abs_roll=[]
check=False
check_res=False
check_analyse=False
check_result_sub=False
context1={}
context2={}
all_pass_bar=[]
all_fail_bar=[]
dff=pd.DataFrame()
def index(request):
    # Mydata.objects.all().delete()
    # Reference.objects.all().delete()
        
    return render(request,'home.html')    

def home(request):
    global check
    
    # Mydata.objects.all().delete()
    # Reference.objects.all().delete()
    if(check==True):
        print(context1)
        return render(request,'index.html',{'context':context1})    
    else: 
        return render(request,'home.html')

@csrf_exempt
def func(request): 
    if request.method == 'POST':
        data=Mydata()
        reference=Reference()
        table2 = request.FILES['myFile']
        name__=str(table2)
         
        name_=name__.split('.')[0]
        tabula.convert_into(table2, "media/"+name_+".csv", output_format="csv", pages='all')
        file='media/'+name_+'.csv'
        df = pd.read_csv('media/'+name_+'.csv')
        # if(os.path.exists(file) and os.path.isfile(file)):
        #         os.remove(file)
        df=df.dropna(subset=['Unnamed: 0'])
        global subjects
        subjects=list(df.columns)
        subjects.insert(0,"RollNo")
        subjects[1]="SGPA"
        subjects[2]="CGPA"
        subjects.pop()
        df.columns=subjects
        df = df.loc[:, ~df.columns.str.contains('^Unnamed')]
        global rows
        rows = df.shape[0]
        subjects=list(df.columns)
        subjects.remove('CGPA')
        subjects.remove('SGPA')
        subjects.remove('RollNo')
        df['Semester']=name_
        abs_lis = list(df.apply(lambda  x:",".join(x[x=='Ab'].index.values), axis = 1))
        df['Absenties']=abs_lis
        # abs_no=list(df['Absenties'].apply(lambda x : x if len(list(x.split(','))) ==len(subjects) else len(list(x.split(',')))))
        # abs_no = [int(i) for i in abs_no] 
        df['No_of_ab']='Nan'
        # temp_df=df[df['No_of_ab'] >=6]
        global abs_roll
        # abs_roll=list(temp_df["RollNo"])
        df = df[df['RollNo'].isin(abs_roll) == False] 
        df = df.reset_index()
        list4=[]
        abs_lis=df['Absenties']
        abs_no=df['No_of_ab']
        df=df.drop(columns=['Absenties','No_of_ab'])
        df['Failed_Subjects']="NaN"
        df['Passed_Subjects']="NaN"
        df['No_of_backlogs']='Nan'
        # df['Failed_Subjects']=df.apply(lambda rows :list4.append(x) for x in rows, axis = 1)
        failed=[]
        
        failed=list(df.apply(lambda  x:",".join(x[x=='F'].index.values), axis = 1))
     
        df['Failed_Subjects']=failed
        df2=df.drop(columns=['index','RollNo','SGPA','CGPA','Failed_Subjects','Passed_Subjects','Semester','No_of_backlogs'])
  
        df['Passed_Subjects']=list(df2.apply(lambda  x:",".join(x[(x!='F') & (x!='Ab')].index.values), axis = 1)) 
        # df['Passed Subjects']=list(df2.apply(lambda x:",".join(x[(x!='Ab') | (x!='F')].index.values),axis=1))
        df = df.reset_index()
        #print(subjects)
        for i in range(0,len(failed)):
            if(failed[i]==''):
                df['No_of_backlogs'][i]=0
            else:
                # print(len(list(i.split(","))))
                df['No_of_backlogs'][i]=len(list(failed[i].split(','))) 
        del df2
        df=df.drop(columns=['index'])
        
        for i in subjects:
                df.drop(columns=i, axis=1, inplace=True)
        mid_roll=int(rows/2)
        midroll=df['RollNo'][mid_roll]
        passing_year=int(midroll[:2])+4
        df['Passed_Out_Year']=passing_year
        global pass_y
        pass_y=passing_year
        global sem
        sem=name_
        global detain
        detain=[]
        l=midroll[:2]
        global dff
        dff=df
        # print(midroll[:2])
        for i in range(0,df.shape[0]):
            if(df.iloc[i]['RollNo'][:2]!=l):
                detain.append(df.iloc[i]['RollNo'])  
        person=detain
        war_msg=None
        if  Reference.objects.filter(Passed_Out_Year=pass_y, Semester=sem).exists():
            war_msg=(name__," Already exists")
        else: 
            war_msg=(" "+name__+" Uploded")

        subs={}
        for i in subjects:
            subs[i]=i
        df['Absent_subjects']=abs_lis
        # print(df)
        df.to_csv('final.csv')
        global check_analyse
        check_analyse=True
        context={
            'war_msg':war_msg,
            "list":person,
            'subjects':subjects,
        }
        #print(subjects)
        return JsonResponse({'context':context})  
    return render(request,'index.html')    
def bar_graph(seca,secb,secc,secd):
    a_fai=list(seca['Failed_Subjects'])
    a_pass=a_fai.count('')
    a_fail=len(a_fai)-int(a_pass)
    b_fai=list(secb['Failed_Subjects'])
    b_pass=b_fai.count('')
    b_fail=len(b_fai)-int(b_pass)
    
    c_fai=list(secc['Failed_Subjects'])
    c_pass=c_fai.count('')
    c_fail=len(c_fai)-int(c_pass)
    d_fai=list(secd['Failed_Subjects'])
    d_pass=d_fai.count('')
    d_fail=len(d_fai)-int(d_pass)
    all_pass=[a_pass,b_pass,c_pass,d_pass]
    all_fail=[a_fail,b_fail,c_fail,d_fail]
    n_pass=sum(all_pass)
    n_fail=sum(all_fail)
    return(all_pass,all_fail,n_pass,n_fail)


def area_graph(sem_graph,i):
    a_fai=list(sem_graph.loc[sem_graph['Semester'] == i, 'Failed_Subjects'])
    a_pass=a_fai.count('')
    a_fail=len(a_fai)-int(a_pass)
    return a_pass,a_fail
@csrf_exempt
def analyize(request):
    if request.method == 'POST':
        if(check_analyse==True):
            y=str(pass_y-4)
            # df = pd.DataFrame(list(Mydata.objects.filter(Passed_Out_Year=pass_y,Semester=sem).values()))
            df=dff
            reference=Reference()
            df['Section']='Nan'
            sec_a_faculty=[]
            sec_b_faculty=[]
            sec_c_faculty=[]
            sec_d_faculty=[]
            sec_a_faculty=request.POST.getlist('a_')
            sec_b_faculty=request.POST.getlist('b_')
            sec_c_faculty=request.POST.getlist('c_')
            sec_d_faculty=request.POST.getlist('d_')

            sf=df[df['RollNo'].str.startswith(y)]  

            seca=sf[sf['RollNo'].str[-3:]<'561']
            secb1=sf[sf['RollNo'].str[-3:]>'560']
            secb2=sf[sf['RollNo'].str[-3:]<'5C1']

            secc1=sf[sf['RollNo'].str[-3:]>'5C0']
            secc2=sf[sf['RollNo'].str[-3:]<'5J1']
            # secb=pd.merge(sf[sf['RollNo'].str[-3:]>'560'],sf[sf['RollNo'].str[-3:]<'5C1'],how='outer',on=['RollNo'])
            # secc=pd.merge(sf[sf['RollNo'].str[-3:]>'5C0'],sf[sf['RollNo'].str[-3:]<'5J1'],how='outer',on=['RollNo'])
            secd=sf[sf['RollNo'].str[-3:]>'5J0']
            secb = secb1[secb1['RollNo'].isin(secb2['RollNo'])].reset_index(drop=True)
            secc = secc1[secc1['RollNo'].isin(secc2['RollNo'])].reset_index(drop=True)
            
            sec_al=request.POST.get('Sec-A')
            sec_bl=request.POST.get('Sec-B')
            sec_cl=request.POST.get('Sec-C')
            sec_dl=request.POST.get('Sec-D')
            Sec_A=list(sec_al.split(','))[:-1]
            Sec_B=list(sec_bl.split(','))[:-1]
            Sec_C=list(sec_cl.split(','))[:-1]
            Sec_D=list(sec_dl.split(','))[:-1]
            for i in Sec_A:
                entry = df.loc[df['RollNo'] == i]
                detain.remove(i)
                seca=pd.concat([seca,entry])
            for i in Sec_B:
                entry = df.loc[df['RollNo'] == i]
                detain.remove(i)
                secb=pd.concat([secb,entry])
            for i in Sec_C:
                entry = df.loc[df['RollNo'] == i]
                detain.remove(i)
                secc=pd.concat([secc,entry])
            for i in Sec_D:
                entry = df.loc[df['RollNo'] == i]
                detain.remove(i)
                secd=pd.concat([secd,entry])
            seca["Section"]='A'
            secb["Section"]='B'
            secc["Section"]='C'
            secd["Section"]='D'
            frames = [seca,secb,secc,secd]
            result = pd.concat(frames)
            result.to_csv('final.csv')
            global all_pass_bar

            global all_fail_bar
            all_pass_bar,all_fail_bar,n_pass_bar,n_fail_bar=bar_graph(seca,secb,secc,secd)
            aa=all_pass_bar[0]
            bb=all_pass_bar[1]
            cc=all_pass_bar[2]
            dd=all_pass_bar[3]
            total_pass_per=round((sum(all_pass_bar)/result.shape[0])*100,2)
            pass_percentage=[]
            fail_percentage=[]
            for i in range(0,len(all_pass_bar)):

                n=all_pass_bar[i]+all_fail_bar[i]
                per=(all_pass_bar[i]/n)*100
                pass_percentage.append(round(per,2))
                fail_percentage.append(round(100-per,2))
            
            per_f=0
            per_p=0
            dict_s={}
            total_res=[]
            total=(','.join(df['Failed_Subjects'].tolist())).split(',') 
            for i in subjects:
                _rows = df.shape[0]
                c=total.count(i)
                per_f=round((c/_rows)*100,2)
                per_p=round(100-per_f,2)
                total_res.append(_rows)
                total_res.append(_rows-c)
                total_res.append(c)
                total_res.append(per_p)
                total_res.append(per_f)
                dict_s[i]=total_res
                total_res=[]
            # toal subjects are calculate above 
            # now calculate the individual sections below
            seca_res={}
            secb_res={}
            secc_res={}
            secd_res={}
            sec_a_res=[]
            sec_b_res=[]
            sec_c_res=[]
            sec_d_res=[]
            #print("AAAAAAAAAAAAA")
            list1=(','.join(seca['Passed_Subjects'].tolist())).split(',') 
            list2=(','.join(secb['Passed_Subjects'].tolist())).split(',') 
            list3=(','.join(secc['Passed_Subjects'].tolist())).split(',') 
            list4=(','.join(secd['Passed_Subjects'].tolist())).split(',') 
            #print(list1)
            k=0
            for i in subjects:
                a_rows = seca.shape[0]
                c=list1.count(i)
                per_p=round((c/a_rows)*100,2)
                sec_a_res.append(sec_a_faculty[k])
                sec_a_res.append(a_rows)
                sec_a_res.append(c)
                sec_a_res.append(a_rows-c)
                sec_a_res.append(per_p)
                seca_res[i]=sec_a_res
                sec_a_res=[]
                b_rows = secb.shape[0]

                c=list2.count(i)
                per_p=round((c/b_rows)*100,2)
                sec_b_res.append(sec_b_faculty[k])

                sec_b_res.append(b_rows)
                sec_b_res.append(c)
                sec_b_res.append(b_rows-c)
                sec_b_res.append(per_p)

                secb_res[i]=sec_b_res
                sec_b_res=[]
                c_rows = secc.shape[0]
                c=list3.count(i)
                per_p=round((c/c_rows)*100,2)
                sec_c_res.append(sec_c_faculty[k])

                sec_c_res.append(c_rows)
                sec_c_res.append(c)
                sec_c_res.append(c_rows-c)
                sec_c_res.append(per_p)

                secc_res[i]=sec_c_res
                sec_c_res=[]
                d_rows = secd.shape[0]
                c=list4.count(i)
                per_p=round((c/d_rows)*100,2)
                sec_d_res.append(sec_d_faculty[k])

                sec_d_res.append(d_rows)
                sec_d_res.append(c)
                sec_d_res.append(d_rows-c)
                sec_d_res.append(per_p)
                secd_res[i]=sec_d_res
                sec_d_res=[]
                k=k+1
                
            # for i in range(0,len(subjects)):
            #     sec_a_res.insert(1,sec_a_faculty[i])
            #     sec_b_res.insert(1,sec_b_faculty[i])
            #     sec_c_res.insert(1,sec_c_faculty[i])
            #     sec_d_res.insert(1,sec_d_faculty[i])
            result = result.drop('level_0', 1)
            
                    # else:
                        # print("Detains and lES are not all selected")
            # Count number of True in series

            

            # Total_3_failed = len(total_failed_[total_failed_ == True].index)
            total_failed_ = result['No_of_backlogs'][result['No_of_backlogs'] >2 ].count()
            t_1_fail=(result['No_of_backlogs'] == 1).sum()
            t_2_fail=(result['No_of_backlogs'] == 2).sum()

            a_1_fail=(seca['No_of_backlogs'] == 1).sum()
            a_2_fail=(seca['No_of_backlogs'] == 2).sum()
            a_3_failed_ = seca['No_of_backlogs'][seca['No_of_backlogs'] >2 ].count()


            b_1_fail=(secb['No_of_backlogs'] == 1).sum()
            b_2_fail=(secb['No_of_backlogs'] == 2).sum()
            b_3_failed_ = secb['No_of_backlogs'][secb['No_of_backlogs'] >2 ].count()



            c_1_fail=(secc['No_of_backlogs'] == 1).sum()
            c_2_fail=(secc['No_of_backlogs'] == 2).sum()
            c_3_failed_ = secc['No_of_backlogs'][secc['No_of_backlogs'] >2 ].count()



            d_1_fail=(secd['No_of_backlogs'] == 1).sum()
            d_2_fail=(secd['No_of_backlogs'] == 2).sum()
            d_3_failed_ = secd['No_of_backlogs'][secd['No_of_backlogs'] >2 ].count()


            eee=a_3_failed_+b_3_failed_+c_3_failed_+d_3_failed_


            A_sec_failed=[a_1_fail,a_2_fail,a_3_failed_]
            B_sec_failed=[b_1_fail,b_2_fail,b_3_failed_]
            C_sec_failed=[c_1_fail,c_2_fail,c_3_failed_]
            D_sec_failed=[d_1_fail,d_2_fail,d_3_failed_]
            T_sec_failed=[t_1_fail,t_2_fail,total_failed_]
            if  Reference.objects.filter(Passed_Out_Year=pass_y, Semester=sem).exists():
                    pass
            else:
                    
                    # if(len(detain)==0):
                Mydata.objects.bulk_create(Mydata(**vals) for vals in result.to_dict('records'))
                reference.Passed_Out_Year=pass_y
                reference.Semester=sem
                reference.Subjects=",".join(subjects)
                reference.Absenties=",".join(abs_roll)
                reference.save()
            sem_graph=pd.DataFrame(list(Mydata.objects.filter(Passed_Out_Year=pass_y).values()))
            sems=list(set(sem_graph['Semester']))
            # sem_graph=[0,0,0,0]
            # sems=[0,0,0,0]
            sem_pass=[]
            sem_fail=[]
            for i in sorted(sems):
                k,j=area_graph(sem_graph,i)
                sem_pass.append(k)
                sem_fail.append(j)
            n=n_pass_bar+n_fail_bar
            
            table=Mydata.objects.filter(Passed_Out_Year=pass_y,Semester=sem)
            print(type(list(result['CGPA'])[0]))
    
            total_top_table=result.sort_values(by=['CGPA'], ascending=False)
            A_top_table=seca.sort_values(by=['CGPA'], ascending=False)
            B_top_table=secb.sort_values(by=['CGPA'], ascending=False)
            C_top_table=secc.sort_values(by=['CGPA'], ascending=False)
            D_top_table=secd.sort_values(by=['CGPA'], ascending=False)
            # total_top_table.drop(columns=['SGPA']) 
            var1=total_top_table[['RollNo','CGPA']].iloc[0:5]
            total_top_roll=list(var1['RollNo'])
            total_top_cgpa=list(var1['CGPA'])

            var1=A_top_table[['RollNo','CGPA']].iloc[0:5]
            A_top_roll=list(var1['RollNo'])
            A_top_cgpa=list(var1['CGPA'])

            var1=B_top_table[['RollNo','CGPA']].iloc[0:5]
            B_top_roll=list(var1['RollNo'])
            B_top_cgpa=list(var1['CGPA'])

            var1=C_top_table[['RollNo','CGPA']].iloc[0:5]
            C_top_roll=list(var1['RollNo'])
            C_top_cgpa=list(var1['CGPA'])

            var1=D_top_table[['RollNo','CGPA']].iloc[0:5]
            D_top_roll=list(var1['RollNo'])
            D_top_cgpa=list(var1['CGPA'])
            total_top={}
            a_top={}
            b_top={}
            c_top={}
            d_top={}

            for i in range(0,5):
                total_top[total_top_roll[i]]=total_top_cgpa[i]
                a_top[A_top_roll[i]]=A_top_cgpa[i]
                b_top[B_top_roll[i]]=B_top_cgpa[i]
                c_top[C_top_roll[i]]=C_top_cgpa[i]
                d_top[D_top_roll[i]]=D_top_cgpa[i]
            print(all_pass_bar)



            global context1 
            global check
            check=True
            context1={ 
                'n':n,
                'np':n_pass_bar,
                'nf':n_fail_bar,
                'sem':sem,
                'lis':table,
                'dict_s':dict_s, 
                'seca_res':seca_res,
                'secb_res':secb_res,
                'secc_res':secc_res,
                "secd_res":secd_res,
                'A_sec_failed':A_sec_failed,
                'B_sec_failed':B_sec_failed,
                'C_sec_failed':C_sec_failed,
                'D_sec_failed':D_sec_failed,
                'T_sec_failed':T_sec_failed,
                'pass_':all_pass_bar,
                'fail_':all_fail_bar,
                'sem_pass':sem_pass,
                'aa':aa,
                'bb':bb,
                'cc':cc,
                'dd':dd,
                'sem_fail':sem_fail,
                'sems':sorted(sems),
                'total_pass_per':total_pass_per,
                'pass_percentage':pass_percentage,
                'fail_percentage':fail_percentage,
                'total_top_roll':total_top_roll,
                'total_top_cgpa':total_top_cgpa,
                'A_top_roll':A_top_roll,
                'A_top_cgpa':A_top_cgpa,
                'B_top_roll':B_top_roll,
                'B_top_cgpa':B_top_cgpa,
                'C_top_roll':C_top_roll,
                'C_top_cgpa':C_top_cgpa,
                'D_top_roll':D_top_roll,
                'D_top_cgpa':D_top_cgpa,

                'total_top':total_top,
                    'a_top':a_top,
                    'b_top':b_top,
                    'c_top':c_top,
                    'd_top':d_top,

            }
            return render(request,'index.html',{'context':context1}) 
        else:
            errmsg="Upload a file to analyse"
            context={
                'errmsg':errmsg,
            }
            return render(request,'home.html',{'context':context})

    return render(request,'index.html')

@csrf_exempt
def retrive(request):
    ref=pd.DataFrame(list(Reference.objects.all().values()))    
    data_check=len(ref.index)
    if(data_check==0):
        return render(request,'home.html')
    else:
        # ref=ref.tolist() 
        # print(ref)
        sems__=ref['Semester']
        # pass_year=ref['Passed_Out_Year']
        pass_year=(ref.Passed_Out_Year.unique()) 
        if request.method == 'POST':
                # _sem='1-2-CSE'
                # p_y=23  
                try:
                    _sem=request.POST.get('sem')
                    p_y=request.POST.get('passoutyear')
                    print(_sem,p_y) 
                    sem_pd=pd.DataFrame(Mydata.objects.filter(Passed_Out_Year=p_y,Semester=_sem).values())
                    seca_=pd.DataFrame(Mydata.objects.filter(Passed_Out_Year=p_y,Semester=_sem,Section='A').values())
                    secb_=pd.DataFrame(Mydata.objects.filter(Passed_Out_Year=p_y,Semester=_sem,Section='B').values())
                    secc_=pd.DataFrame(Mydata.objects.filter(Passed_Out_Year=p_y,Semester=_sem,Section='C').values())
                    secd_=pd.DataFrame(Mydata.objects.filter(Passed_Out_Year=p_y,Semester=_sem,Section='D').values())

                    d=pd.DataFrame(Reference.objects.filter(Passed_Out_Year=p_y,Semester=_sem).values())
                    temp=d['Subjects'].tolist()
                    # subjects_=temp[2:-2]
                    subjects_=str(temp)
                    subjects__=str(subjects_[2:-2])
                    subjects_=subjects__.split(',')
                    print(subjects_)

                    #subject wise
                    per_f=0
                    per_p=0 
                    dict_s={}
                    total_res=[]
                    n=sem_pd.shape[0]
                    total=(','.join(sem_pd['Failed_Subjects'].tolist())).split(',') 
                    for i in subjects_:
                        _rows = sem_pd.shape[0]
                        c=total.count(i)
                        per_f=round((c/_rows)*100,2)
                        per_p=round(100-per_f,2)
                        total_res.append(_rows)
                        total_res.append(_rows-c)
                        total_res.append(c)
                        total_res.append(per_p)
                        total_res.append(per_f)
                        dict_s[i]=total_res
                        print(total_res)
                        total_res=[]
                    print(dict_s) 
                    # toal subjects are calculate above 
                    # now calculate the individual sections below
                    seca_res={}
                    secb_res={}
                    secc_res={}
                    secd_res={}
                    sec_a_res=[]
                    sec_b_res=[]
                    sec_c_res=[]
                    sec_d_res=[]
                    #print("AAAAAAAAAAAAA")
                    list1=(','.join(seca_['Passed_Subjects'].tolist())).split(',') 
                    list2=(','.join(secb_['Passed_Subjects'].tolist())).split(',') 
                    list3=(','.join(secc_['Passed_Subjects'].tolist())).split(',') 
                    list4=(','.join(secd_['Passed_Subjects'].tolist())).split(',') 
                    #print(list1)
                    k=0
                    for i in subjects_:
                        a_rows = seca_.shape[0]
                        c=list1.count(i)
                        per_p=round((c/a_rows)*100,2)
                        sec_a_res.append("_")
                        sec_a_res.append(a_rows)
                        sec_a_res.append(c)
                        sec_a_res.append(a_rows-c)
                        sec_a_res.append(per_p)
                        seca_res[i]=sec_a_res
                        sec_a_res=[]


                        b_rows = secb_.shape[0]
                        c=list2.count(i)
                        per_p=round((c/b_rows)*100,2)            
                        sec_b_res.append("_")


                        sec_b_res.append(b_rows)
                        sec_b_res.append(c)
                        sec_b_res.append(b_rows-c)
                        sec_b_res.append(per_p)
                        secb_res[i]=sec_b_res
                        sec_b_res=[]

                        c_rows = secc_.shape[0]
                        c=list3.count(i)
                        per_p=round((c/c_rows)*100,2)
                        sec_c_res.append("_")


                        sec_c_res.append(c_rows)
                        sec_c_res.append(c)
                        sec_c_res.append(c_rows-c)
                        sec_c_res.append(per_p)
                        secc_res[i]=sec_c_res
                        sec_c_res=[]

                        d_rows = secd_.shape[0]
                        c=list4.count(i)
                        per_p=round((c/d_rows)*100,2)
                        sec_d_res.append("_") 
                        sec_d_res.append(d_rows)
                        sec_d_res.append(c)
                        sec_d_res.append(d_rows-c)
                        sec_d_res.append(per_p)
                        secd_res[i]=sec_d_res
                        sec_d_res=[]
                        k=k+1


                    
                    # Total analyize 1
                    all_pass_bar,all_fail_bar,n_pass_bar,n_fail_bar=bar_graph(seca_,secb_,secc_,secd_)
                    print(all_pass_bar,all_fail_bar)
                    aa=all_pass_bar[0]
                    bb=all_pass_bar[1]
                    cc=all_pass_bar[2]
                    dd=all_pass_bar[3]

                    total_pass_per=round((sum(all_pass_bar)/sem_pd.shape[0])*100,2)
                    # pass_percentage=[]
                    # fail_percentage=[]
                    # for i in range(0,len(all_pass_bar)):
                    #     n=all_pass_bar[i]+all_fail_bar[i]
                    #     per=(all_pass_bar[i]/n)*100
                    #     pass_percentage.append(round(per,2))
                    #     fail_percentage.append(round(100-per,2))
                    # print(pass_percentage,fail_percentage)






                    # Total Analysis 2
                    total_failed_ = sem_pd['No_of_backlogs'][sem_pd['No_of_backlogs'] >2 ].count()
                    t_1_fail=(sem_pd['No_of_backlogs'] == 1).sum()
                    t_2_fail=(sem_pd['No_of_backlogs'] == 2).sum()

                    a_1_fail=(seca_['No_of_backlogs'] == 1).sum()
                    a_2_fail=(seca_['No_of_backlogs'] == 2).sum()
                    a_3_failed_ = seca_['No_of_backlogs'][seca_['No_of_backlogs'] >2 ].count()


                    b_1_fail=(secb_['No_of_backlogs'] == 1).sum()
                    b_2_fail=(secb_['No_of_backlogs'] == 2).sum()
                    b_3_failed_ = secb_['No_of_backlogs'][secb_['No_of_backlogs'] >2 ].count()



                    c_1_fail=(secc_['No_of_backlogs'] == 1).sum()
                    c_2_fail=(secc_['No_of_backlogs'] == 2).sum()
                    c_3_failed_ = secc_['No_of_backlogs'][secc_['No_of_backlogs'] >2 ].count()



                    d_1_fail=(secd_['No_of_backlogs'] == 1).sum()
                    d_2_fail=(secd_['No_of_backlogs'] == 2).sum()
                    d_3_failed_ = secd_['No_of_backlogs'][secd_['No_of_backlogs'] >2 ].count()


                    eee=a_3_failed_+b_3_failed_+c_3_failed_+d_3_failed_


                    A_sec_failed=[a_1_fail,a_2_fail,a_3_failed_]
                    B_sec_failed=[b_1_fail,b_2_fail,b_3_failed_]
                    C_sec_failed=[c_1_fail,c_2_fail,c_3_failed_]
                    D_sec_failed=[d_1_fail,d_2_fail,d_3_failed_]
                    T_sec_failed=[t_1_fail,t_2_fail,total_failed_]


                    total_top_table=sem_pd.sort_values(by=['CGPA'], ascending=False)
                    A_top_table=seca_.sort_values(by=['CGPA'], ascending=False)
                    B_top_table=secb_.sort_values(by=['CGPA'], ascending=False)
                    C_top_table=secc_.sort_values(by=['CGPA'], ascending=False)
                    D_top_table=secd_.sort_values(by=['CGPA'], ascending=False)


                    total_top_table.drop(total_top_table.index[total_top_table['CGPA'] == 'nan'], inplace=True)
                    A_top_table.drop(A_top_table.index[A_top_table['CGPA'] == 'nan'], inplace=True)
                    B_top_table.drop(B_top_table.index[B_top_table['CGPA'] == 'nan'], inplace=True)
                    C_top_table.drop(C_top_table.index[C_top_table['CGPA'] == 'nan'], inplace=True)
                    D_top_table.drop(D_top_table.index[D_top_table['CGPA'] == 'nan'], inplace=True)

                    # total_top_table.drop(columns=['SGPA']) 
                    # dfff = C_top_table[C_top_table['CGPA'].notna()]
                    var1=total_top_table[['RollNo','CGPA']].iloc[0:5]
                    total_top_roll=list(var1['RollNo'])
                    total_top_cgpa=list(var1['CGPA'])

                    var1=A_top_table[['RollNo','CGPA']].iloc[0:5]
                    A_top_roll=list(var1['RollNo'])
                    A_top_cgpa=list(var1['CGPA'])

                    var1=B_top_table[['RollNo','CGPA']].iloc[0:5]
                    B_top_roll=list(var1['RollNo'])
                    B_top_cgpa=list(var1['CGPA'])

                    var1=C_top_table[['RollNo','CGPA']].iloc[0:5]
                    C_top_roll=list(var1['RollNo'])
                    C_top_cgpa=list(var1['CGPA'])

                    var1=D_top_table[['RollNo','CGPA']].iloc[0:5]
                    D_top_roll=list(var1['RollNo'])
                    D_top_cgpa=list(var1['CGPA'])
                    total_top={}
                    a_top={}
                    b_top={}
                    c_top={}
                    d_top={}

                    for i in range(0,5):
                        total_top[total_top_roll[i]]=total_top_cgpa[i]
                        print(total_top)
                        a_top[A_top_roll[i]]=A_top_cgpa[i]
                        b_top[B_top_roll[i]]=B_top_cgpa[i]
                        c_top[C_top_roll[i]]=C_top_cgpa[i]
                        d_top[D_top_roll[i]]=D_top_cgpa[i]
                    # total_analysis_1=[aa,bb,cc,dd]
                    print(all_pass_bar)
                    global context2
                    global check_res
                    check_res=True

                    context2={ 
                        'sems__':sems__,
                        'pass_year':pass_year,
                        'sem':_sem,
                        'dict_s':dict_s,                #subject wise table
                        'seca_res':seca_res,            #each section dict for tables
                        'secb_res':secb_res,            #each section dict for tables
                        'secc_res':secc_res,            #each section dict for tables
                        "secd_res":secd_res,            #each section dict for tables
                        'aa':(aa),                        #number of student passed in each section
                        'bb':(bb),                        #number of student passed in each section
                        'cc':(cc),                        #number of student passed in each section
                        'dd':(dd),                        #number of student passed in each section
                        'n':(n),                          #Total number of studnets appeared
                        'np':(n_pass_bar),                #Total number of student passed
                        'total_pass_per':(total_pass_per),#pass percentage of total batch

                        'A_sec_failed':A_sec_failed,    #last table of Total analysis
                        'B_sec_failed':B_sec_failed,    #last table of Total analysis
                        'C_sec_failed':C_sec_failed,    #last table of Total analysis
                        'D_sec_failed':D_sec_failed,    #last table of Total analysis
                        'T_sec_failed':T_sec_failed,    #last table of Total analysis
                        'total_top':total_top,
                        'a_top':a_top,
                        'b_top':b_top,
                        'c_top':c_top,
                        'd_top':d_top,
                        
                        'total_top_roll':total_top_roll,
                        'total_top_cgpa':total_top_cgpa,
                        'A_top_roll':A_top_roll,
                        'A_top_cgpa':A_top_cgpa,
                        'B_top_roll':B_top_roll,
                        'B_top_cgpa':B_top_cgpa,
                        'C_top_roll':C_top_roll,
                        'C_top_cgpa':C_top_cgpa,
                        'D_top_roll':D_top_roll,
                        'D_top_cgpa':D_top_cgpa,
                        'pass_':all_pass_bar,
                        'fail_':all_fail_bar,


                    }
                    return render(request,'results.html',{'context':context2})
                except:
                    errmsg="Something happend please try again"
                    context={
                        'errmsg':errmsg,
                    }
                    return render(request,'home.html',{'context':context})
    
        ref=pd.DataFrame(list(Reference.objects.all().values()))    
        # ref=ref.tolist() 
        # print(ref)
        sems__=ref['Semester']
        # pass_year=ref['Passed_Out_Year']
        pass_year=(ref.Passed_Out_Year.unique()) 
        print(pass_year) 
        # pass_year=pass_year.sort(reverse=True)
        if(check_res==False):
            context={
                'sems__':sems__,
                'pass_year':sorted(pass_year , reverse=True),
            }
            return render(request,'results.html',{'context':context})

        else:
            context2['sems__']=sems__
            context2['pass_year']=sorted(pass_year , reverse=True)
            print(check)
            return render(request,'results.html',{'context':context2})