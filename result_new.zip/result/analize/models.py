from django.db import models

class Mydata(models.Model):
    RollNo=models.CharField(max_length=30)
    SGPA=models.CharField(max_length=30)
    CGPA=models.CharField(max_length=30)
    Failed_Subjects= models.CharField(max_length=30)
    Passed_Subjects= models.CharField(max_length=30)
    Passed_Out_Year= models.CharField(max_length=30)
    Semester=models.CharField(max_length=30)
    Section=models.CharField(max_length=30)
    No_of_backlogs=models.IntegerField()
    Absent_subjects=models.CharField(max_length=30)
    def __str__(self):
        return self.RollNo
class Reference(models.Model):
    Subjects= models.CharField(max_length=30)
    Passed_Out_Year= models.CharField(max_length=30)
    Semester=models.CharField(max_length=30)
    Absenties=models.CharField(max_length=30)
    # def __str__(self):
    #     return self.Passed_Out_Year

# Create your models here.
